# Documentation Manifest

Generated: 2026-08-31

## Files
- `./README.md`
- `./docToolchainConfig.groovy`
- `./scripts/bootstrap-docs.sh`
- `./scripts/build-docs.sh`
- `./src/docs/arc42/adrs/ADR-001-go.adoc`
- `./src/docs/arc42/adrs/ADR-002-layered-ports-adapters.adoc`
- `./src/docs/arc42/adrs/ADR-003-provider-capability-routing.adoc`
- `./src/docs/arc42/adrs/ADR-004-change-aggregate-state-machine.adoc`
- `./src/docs/arc42/adrs/ADR-005-change-surface-control.adoc`
- `./src/docs/arc42/adrs/ADR-006-deterministic-verification.adoc`
- `./src/docs/arc42/adrs/ADR-007-external-project-memory.adoc`
- `./src/docs/arc42/adrs/ADR-008-memory-representation.adoc`
- `./src/docs/arc42/adrs/ADR-009-local-memory-index.adoc`
- `./src/docs/arc42/adrs/ADR-010-append-oriented-audit.adoc`
- `./src/docs/arc42/adrs/ADR-011-memory-lifecycle-invalidation.adoc`
- `./src/docs/arc42/adrs/ADR-012-isolated-code-proposals.adoc`
- `./src/docs/arc42/adrs/ADR-013-maker-checker.adoc`
- `./src/docs/arc42/adrs/ADR-014-provider-trust-boundaries.adoc`
- `./src/docs/arc42/adrs/ADR-015-doctoolchain.adoc`
- `./src/docs/arc42/adrs/ADR-016-naming-clarity.adoc`
- `./src/docs/arc42/adrs/ADR-017-project-organization-memory.adoc`
- `./src/docs/arc42/adrs/ADR-018-source-memory-workflow-separation.adoc`
- `./src/docs/arc42/appendices/change-state-machine.adoc`
- `./src/docs/arc42/appendices/competitive-landscape.adoc`
- `./src/docs/arc42/appendices/configuration-model.adoc`
- `./src/docs/arc42/appendices/documentation-governance.adoc`
- `./src/docs/arc42/appendices/domain-model.adoc`
- `./src/docs/arc42/appendices/memory-model.adoc`
- `./src/docs/arc42/appendices/policy-model.adoc`
- `./src/docs/arc42/appendices/requirements-catalog.adoc`
- `./src/docs/arc42/appendices/roadmap.adoc`
- `./src/docs/arc42/appendices/security-threat-model.adoc`
- `./src/docs/arc42/appendices/source-notes.adoc`
- `./src/docs/arc42/appendices/validation-strategy.adoc`
- `./src/docs/arc42/appendices/workflow-and-command-model.adoc`
- `./src/docs/arc42/arc42.adoc`
- `./src/docs/arc42/chapters/01-introduction-and-goals.adoc`
- `./src/docs/arc42/chapters/02-constraints.adoc`
- `./src/docs/arc42/chapters/03-context-and-scope.adoc`
- `./src/docs/arc42/chapters/04-solution-strategy.adoc`
- `./src/docs/arc42/chapters/05-building-block-view.adoc`
- `./src/docs/arc42/chapters/06-runtime-view.adoc`
- `./src/docs/arc42/chapters/07-deployment-view.adoc`
- `./src/docs/arc42/chapters/08-crosscutting-concepts.adoc`
- `./src/docs/arc42/chapters/09-architecture-decisions.adoc`
- `./src/docs/arc42/chapters/10-quality-requirements.adoc`
- `./src/docs/arc42/chapters/11-risks-and-technical-debt.adoc`
- `./src/docs/arc42/chapters/12-glossary.adoc`
- `./src/docs/arc42/diagrams/c4-container.puml`
- `./src/docs/arc42/diagrams/c4-context.puml`
- `./src/docs/arc42/diagrams/c4-core-components.puml`
- `./src/docs/arc42/diagrams/c4-deployment-local.puml`
- `./src/docs/arc42/diagrams/c4-memory-components.puml`
- `./src/docs/arc42/diagrams/dynamic-change-execution.puml`
- `./src/docs/arc42/diagrams/dynamic-memory-promotion.puml`
- `./src/docs/arc42/diagrams/dynamic-project-attach.puml`

## Build note

The AsciiDoc include graph was checked locally and contains no missing local include targets.
Rendering through docToolchain was not executed in the sandbox because the runtime cannot resolve external hosts to download the docToolchain distribution. The bootstrap script is included for a normal networked development machine.
